import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor() {
    this.tasks = JSON.parse(localStorage.getItem("data")) || [];
  }

  tasks:Array<string>;
  val:string;

  setTask(src):void {
    this.tasks.push(src.value);
    src.value='';
    localStorage.setItem("data", JSON.stringify(this.tasks));
    src.focus();
  }
  delTask(index):void {
    this.tasks.splice(index, 1);
    localStorage.setItem("data", JSON.stringify(this.tasks));
  }
}
